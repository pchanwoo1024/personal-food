# AI 기반 개인 맞춤 식단 추천 시스템

이 앱은 키, 몸무게, 활동량, 증상, 알레르기 등을 바탕으로
사용자에게 맞는 아침/점심/저녁 식단과 영양제 섭취 일정을 추천해주는 머신러닝 기반 웹앱입니다.

## 실행 방법

```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

또는 Streamlit Cloud에서 실행:
https://share.streamlit.io/사용자명/저장소명/main/streamlit_app.py
